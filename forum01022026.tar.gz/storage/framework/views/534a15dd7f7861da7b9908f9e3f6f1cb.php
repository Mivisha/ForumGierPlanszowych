<div class="mb-4">
    <h1 class="text-2xl font-bold"><?php echo e(__('translation.navigation.users')); ?></h1>
</div>
<?php /**PATH /var/www/html/resources/views/partials/user-heading.blade.php ENDPATH**/ ?>