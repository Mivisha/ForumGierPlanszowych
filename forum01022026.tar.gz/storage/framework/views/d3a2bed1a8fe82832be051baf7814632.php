
<div x-data="{ 
    show: <?php echo \Illuminate\Support\Js::from(session()->has('flash'))->toHtml() ?>, 
    message: <?php echo \Illuminate\Support\Js::from(session('flash.message', ''))->toHtml() ?>,
    type: <?php echo \Illuminate\Support\Js::from(session('flash.type', 'success'))->toHtml() ?>
}" 
     @flash-message.window="show = true; message = $event.detail[0]?.message || $event.detail.message; type = $event.detail[0]?.type || $event.detail.type || 'success'; setTimeout(() => show = false, 5000)"
     x-show="show" 
     x-cloak
     x-init="if(show) setTimeout(() => show = false, 5000)"
     :class="{
         'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200': type === 'success',
         'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200': type === 'warning',
         'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200': type === 'danger'
     }"
     class="mb-4 p-4 rounded-lg flex items-center justify-between"
     style="display: none;"
     x-style="display: show ? '' : 'none'">
    <div class="flex items-center gap-2">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        <span x-text="message"></span>
    </div>
    <button @click="show = false" 
            :class="{
                'text-green-800 dark:text-green-200 hover:text-green-900': type === 'success',
                'text-yellow-800 dark:text-yellow-200 hover:text-yellow-900': type === 'warning',
                'text-red-800 dark:text-red-200 hover:text-red-900': type === 'danger'
            }">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
        </svg>
    </button>
</div>

<div class="mb-4 flex items-center justify-between">
    <div>
        <h1 class="text-2xl font-bold"><?php echo e(__('translation.navigation.boardgames')); ?></h1>
    </div>
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\BoardGame::class)): ?>
        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'primary','icon' => 'plus','href' => route('board-games.create'),'wire:navigate' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'primary','icon' => 'plus','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('board-games.create')),'wire:navigate' => true]); ?>
            <?php echo e(__('boardgames.actions.create')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
    <?php endif; ?>
</div>


<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('board-games.view-board-game-modal');

$key = null;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2029374234-0', null);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH /var/www/html/resources/views/partials/boardgame-heading.blade.php ENDPATH**/ ?>